using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TutorialPickup : Pickup
{
    public GameObject tutorialMessage;
    public float timeShowup = 5;
    public float timeToShow = 0;
    public Text text;

    public override void DoOnPickup(Collider2D collision)
    {
        if(collision.tag == "Player" && collision.gameObject.GetComponent<Health>() != null)
        {
            if (this.tag.Equals("Tutorial1"))
            {
                text.text = "Movement: A to left; D to right";
            }
            if (this.tag.Equals("Tutorial2"))
            {
                text.text = "Jump: space";
            }
            if (this.tag.Equals("Tutorial3"))
            {
                text.text = "double jump: doule press 'space key'";
            }
            tutorialMessage.GetComponentInChildren<Text>().text = text.text;
            tutorialMessage.SetActive(true);
            timeToShow = Time.time + timeShowup;
            Debug.Log("tutorial should appear" + Time.time+ " "+ timeToShow);
        }
    }

    private void Start()
    {
        
    }

    private void Update()
    {
        if(timeToShow>0 && Time.time >= timeToShow)
        {
            tutorialMessage.SetActive(false);
            timeToShow = 0;
        }
    }

}
