using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TutorialPoint : MonoBehaviour
{
    [SerializeField] string tutorialText;
    [SerializeField] bool disableAfterPickup = false;

    [SerializeField] TutorialMessageUI tutorialMessageUIElement;
    void Start()
    {
    }

    private void OnTriggerEnter2D(Collider2D collision) {
        if (collision.gameObject.name.Equals("Player")) {
            tutorialMessageUIElement.displayTutorialMessage(tutorialText);
            gameObject.SetActive(!disableAfterPickup);
        }
    }
}