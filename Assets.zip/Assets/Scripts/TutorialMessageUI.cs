using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class TutorialMessageUI : MonoBehaviour
{
    [SerializeField] Text tutorialText;
    [SerializeField] float activeTime = 5f;
    void Start()
    {

    }

    public void displayTutorialMessage(string message) {

        tutorialText.text = message;
        activatePopup();
        
    }
    /*
     * There is a minor bug in which if you go to another tutorial point while this one is runing the coroutine is not reset. 
     * To fix do:
     * 1) add boolean coroutineRunning = false;
     * in activatePopup(){} add the line if(coroutineRunning) StopCoroutine(); and then start it again;
     * 
     * /!\Note: I think its not really neccesary
     */
    private void activatePopup() {
        gameObject.SetActive(true);  //i tried to activate through coroutine but it didnt work
        StartCoroutine(activateTutorialPopup());
    }
    private IEnumerator activateTutorialPopup() {
        yield return new WaitForSeconds(activeTime);
        gameObject.SetActive(false);
    }
}
